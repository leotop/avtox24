<?
$MESS['LM_AUTO_MAIN_MODULE_NOT_INSTALL'] = "Модуль системы LINEMEDIA_AUTO не установлен";
$MESS['LM_AUTO_MAIN_DETAIL_NOT_FOUND'] = "Деталь не найдена";
$MESS['LM_AUTO_MAIN_TITLE_CATALOG'] = "Каталог автозапчастей";
$MESS['LM_AUTO_MAIN_ALL_MARKS'] = "Все марки";
$MESS['LM_AUTO_MAIN_CATALOG_FOR'] = "Каталог запчастей для";
$MESS['LM_AUTO_MAIN_DETAIL_INFO'] = "детальная информация";
