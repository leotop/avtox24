<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$MESS['LM_AUTO_MAIN_TECDOC_CATALOG_DETAIL_PATH_ROOT'] = "Корневая директория ЧПУ";
$MESS['LM_AUTO_MAIN_TECDOC_CATALOG_DETAIL_PATH_SEARCH'] = "Путь к поиску запчастей (доступны шаблоны #ARTICLE_ID# и #BRAND_ID#)";
$MESS['LM_AUTO_MAIN_TECDOC_CATALOG_DETAIL_SET_TITLE'] = "Установить название в заголовок";
$MESS['LM_AUTO_MAIN_TECDOC_CATALOG_DETAIL_ADD_CHAIN'] = "Добавлять в цепочку навигации";
$MESS['LM_AUTO_MAIN_TECDOC_CATALOG_DETAIL_SHOW_ORIGINAL'] = "Выводить соответсвтие оригинальным номерам";
$MESS['LM_AUTO_MAIN_TECDOC_CATALOG_DETAIL_SHOW_SEARCH_FORM'] = "Выводить поиск по артикулу";
$MESS['LM_AUTO_MAIN_TECDOC_CATALOG_DETAIL_SHOW_APPLICABILITY'] = "Выводить применимость";
$MESS['LM_AUTO_MAIN_TECDOC_CATALOG_DETAIL_SHOW_SEO'] = "Выводить SEO-информацию";
$MESS['LM_AUTO_MAIN_TECDOC_CATALOG_DETAIL_CACHE'] = 'Кэшировать данные';
$MESS['LM_AUTO_MAIN_TECDOC_CATALOG_DETAIL_CACHE_TIME'] = 'Время кэширования';
