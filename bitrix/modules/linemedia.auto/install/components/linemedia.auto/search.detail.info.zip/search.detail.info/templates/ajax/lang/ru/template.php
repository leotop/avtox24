<?

$MESS['LM_AUTO_SEARCH_DETAIL_INFO_ADDITIONAL_INFO'] = 'Детальная информация';
