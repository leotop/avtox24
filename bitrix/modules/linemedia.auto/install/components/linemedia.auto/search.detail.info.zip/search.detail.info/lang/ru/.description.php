<?
$MESS['LM_AUTO_MAIN_SEARCH_DETAIL_INFO_NAME'] = "Информация о запчасти";
$MESS['LM_AUTO_MAIN_SEARCH_DETAIL_INFO_DESCRIPTION'] = "Информация о запчасти из TECDOC";
$MESS['LM_AUTO_MAIN_SECTION'] = "Linemedia Автоэксперт";
$MESS['LM_AUTO_MAIN_SEARCH_SUB_SECTION'] = "Поиск";
