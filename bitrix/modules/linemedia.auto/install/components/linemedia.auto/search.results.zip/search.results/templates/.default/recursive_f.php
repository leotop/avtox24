<?php


/*
function recursive_identical_keys_compose($array, $index, &$composed_array) {

	if (!is_array($array))
		return;

	foreach ($array as $key => $sub_array) {

		if (isset($sub_array[$index])) {
			$composed_array[] = $sub_array[$index];
		}

		recursive_identical_keys_compose($array[$key], $index, $composed_array);
	}
}


*/
