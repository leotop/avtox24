<?
$MESS["LM_AUTO_MODULE_NOT_INSTALL"] = 'Модуль системы linemedia.auto не установлен';
$MESS['LM_AUTO_MAIN_DAYS'] = 'д.';
$MESS['LM_AUTO_MAIN_HOURS'] = 'ч.';
$MESS['LM_AUTO_SEARCH_NEED_AUTH'] = '';
$MESS['LM_AUTO_SEARCH_ALL_TECDOC'] = 'Все марки';
$MESS['LM_AUTO_SEARCH_SEARCH'] = 'Поиск';

$MESS['LM_AUTO_GROUP_100597'] = 'Расходники для ТО';