<?php

$MESS['LM_AUTO_MAIN_SEARCH_FORM_PLACEHOLDER'] = 'Артикул запчасти';
$MESS['LM_AUTO_MAIN_SEARCH_FORM_SUBMIT'] = 'Найти запчасть';
$MESS['LM_AUTO_MAIN_PARTIAL_SEARCH'] = 'Поиск по части артикула';
$MESS['LM_AUTO_SEARCH_NO_SOUGHT_ARTICLE'] = 'Запрошенного артикула не найдено';
