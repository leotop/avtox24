<?php
$MESS['LM_AUTO_QUERY_TITLE'] = 'Название детали для ТО';
$MESS['LM_AUTO_QUERY_COMMENT'] = 'Комментарий детали для ТО';
$MESS['LM_AUTO_QUERY_QUANTITY'] = 'Количество деталей для ТО';
$MESS['LM_AUTO_QUERY_URL'] = 'URL детали для ТО';
$MESS['LM_AUTO_QUERY_KEY'] = 'Номер детали для ТО';
