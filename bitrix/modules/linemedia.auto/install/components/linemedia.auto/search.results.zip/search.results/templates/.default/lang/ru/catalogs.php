<?php

$MESS['LM_AUTO_SEARCH_CATALOG_BRAND_TITLE'] = 'Бренд';
$MESS['LM_AUTO_SEARCH_CATALOG_ITEM_TITLE'] = 'Название';
$MESS['LM_AUTO_SEARCH_CATALOG_SEARCH'] = 'Цены и заменители';
$MESS['LM_AUTO_SEARCH_CATALOG_DEBUG'] = 'Отладка';
$MESS['LM_AUTO_SEARCH_CATALOG_CONTINUE'] = 'Найти';
$MESS['LM_AUTO_SEARCH_CATALOG_HEADER'] = 'Указанный артикул найден в каталогах следующих фирм:';
