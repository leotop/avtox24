<?php
header('Content-type: application/json');
CHTTP::SetStatus('404 Not Found');
exit();