<?php

$MESS['LM_AUTO_MAIN_SEARCH_FORM_PLACEHOLDER'] = 'Артикул запчасти';
$MESS['LM_AUTO_MAIN_SEARCH_FORM_SUBMIT'] = 'Найти запчасть';
$MESS['LM_AUTO_MAIN_PARTIAL_SEARCH'] = 'Поиск по части артикула';
$MESS['CT_BST_SEARCH_ARTICLE'] = 'Артикул';
$MESS['CT_BST_SEARCH_TITLE'] = 'Название';

