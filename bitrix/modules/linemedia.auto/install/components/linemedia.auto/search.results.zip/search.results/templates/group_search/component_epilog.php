<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();
//global $APPLICATION;
//$APPLICATION->AddHeadScript($templateFolder . '/js/tablesorter.js');
//$APPLICATION->AddHeadScript($templateFolder.'/js/jquery.cookie.js');
?>
