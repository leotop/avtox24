<?
$MESS['LM_AUTO_MAIN_SEARCH_RESULT_NAME'] = "Поиск автозапчастей";
$MESS['LM_AUTO_MAIN_SEARCH_RESULT_DESCRIPTION'] = "Вывод результатов поиска";
$MESS['LM_AUTO_MAIN_SECTION'] = "Linemedia Автоэксперт";
$MESS['LM_AUTO_MAIN_SEARCH_SUB_SECTION'] = "Поиск";
