<?php

$MESS['LM_AUTO_ANALOG_GROUP_N'] = 'Искомый артикул';
$MESS['LM_AUTO_ANALOG_GROUP_0'] = 'Неоригинальные аналоги';
$MESS['LM_AUTO_ANALOG_GROUP_1'] = 'OEM аналоги';
$MESS['LM_AUTO_ANALOG_GROUP_2'] = 'Продажные номера';
$MESS['LM_AUTO_ANALOG_GROUP_3'] = 'Сравнительные номера';
$MESS['LM_AUTO_ANALOG_GROUP_4'] = 'Замены';
$MESS['LM_AUTO_ANALOG_GROUP_5'] = 'Замены устаревшего артикула';
$MESS['LM_AUTO_ANALOG_GROUP_6'] = 'EAN';
$MESS['LM_AUTO_ANALOG_GROUP_10'] = 'Другое';
