<?php
$MESS['LM_AUTO_QUANTITY_ROUNDING'] = 'Оставлять знаков после запятой в стоблце "количество"';