<?php

$MESS['LM_AUTO_SEARCH_ERRORS'] = 'При проведении поиска возникли неполадки:';
